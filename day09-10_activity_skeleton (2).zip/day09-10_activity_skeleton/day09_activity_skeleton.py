"""
Day 9 Activity: Data Types Practice
Tasks:
1) Identify numeric-like, currency-like, datetime-like columns
2) Convert to proper dtypes
3) Validate conversions by checking NaN counts
"""

import pandas as pd

raw = {
    "age": ["25", "30", "unknown"],
    "income": ["$50,000", "$60,000", None],
    "signup": ["2024-01-01", "01/05/2024", "not a date"],
}

df = pd.DataFrame(raw)

# TODO: Implement normalize_schema(df) to convert types safely

def normalize_scheama(df):
    df = df.copy()


    numeric_cols = ["age"]
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    

    currency_cols = ["income"]
    for col in currency_cols:

        df[col] = df[col].replace("[\\$,]","",regex=True)
        df[col] = pd.to_numeric(df[col], errors="coerce")

    datatime_cols = ["signup"]
    for col in datatime_cols:
        df[col] = pd.to_datetime(df[col], errors="coerce")

    return df
df_normalized = normalize_scheama(df)

print(df_normalized)
print(df_normalized.isna().sum())